# FloodGuard Myanmar

GeoAI and IoT-based flood monitoring, forecasting, and early-warning system for
Myanmar.

FloodGuard combines local water-level sensors, rainfall observations, weather
forecasts, satellite data, spatial information, and machine-learning models to
estimate flood risk and display warnings on an interactive map dashboard.

> **Project status:** Hackathon MVP — under development

Current dashboard and API capabilities are documented in
[docs/CURRENT_FEATURES.md](docs/CURRENT_FEATURES.md).

The authoritative implementation status, verified dataset/model inventory,
limitations, local runbook, and prioritized roadmap are documented in
[docs/PROJECT_STATUS_AND_ROADMAP.md](docs/PROJECT_STATUS_AND_ROADMAP.md).

## Problem

Flood-prone communities may not receive enough localized, timely, and
easy-to-understand information before water levels become dangerous. Satellite
rainfall products are useful for wide-area analysis, but they are not truly
real-time. For example, NASA IMERG Early Run can arrive several hours after the
observation.

FloodGuard therefore does not depend on one data source. It combines:

- Near-real-time water-level and rainfall sensors
- Forecast rainfall from Open-Meteo
- Satellite and historical rainfall data
- Elevation, slope, river distance, land cover, and other spatial features
- GeoAI predictions and rule-based warning thresholds

## Objectives

- Collect water-level and rainfall readings from IoT stations
- Monitor current conditions on an interactive map
- Forecast whether water levels will rise, remain stable, or fall
- Estimate flood risk for stations and geographic areas
- Classify risk as `LOW`, `MEDIUM`, `HIGH`, or `CRITICAL`
- Notify users when a configured warning threshold is reached
- Provide a foundation that can later expand to additional regions and sensors

## System Architecture

```mermaid
flowchart TD
    S["Water-level and rain sensors"] --> E["ESP32 gateway"]
    E --> M["MQTT broker"]
    M --> A["FastAPI ingestion"]

    W["Open-Meteo forecast"] --> A
    R["Satellite and historical data"] --> A

    A --> D["PostgreSQL + PostGIS"]
    D --> P["GeoAI prediction engine"]
    P --> A
    A --> N["Alert service"]
    A --> U["Next.js map dashboard"]
```

The MVP uses a **modular monolith with an event-driven sensor pipeline**. This
keeps deployment manageable during the hackathon while maintaining clear module
boundaries for future expansion.

## Technology Stack

| Layer | Technologies |
|---|---|
| Frontend | Next.js, App Router, TypeScript, Tailwind CSS |
| Map and charts | Leaflet, React-Leaflet, MapLibre GL JS, CesiumJS, Recharts |
| Client data | TanStack Query, WebSocket |
| Backend | Python, FastAPI, Pydantic, SQLAlchemy |
| Database | PostgreSQL, PostGIS, Alembic |
| Machine learning | Pandas, NumPy, GeoPandas, Scikit-learn, XGBoost |
| Raster and GIS | Rasterio, GDAL, QGIS, Google Earth Engine |
| IoT | ESP32, water-level sensor, rain gauge |
| Messaging | MQTT, Mosquitto |
| External data | Open-Meteo, NASA IMERG, historical and spatial datasets |
| Deployment | Docker, Docker Compose, Vercel, Railway or Render |

## Repository Structure

The frontend, backend, ML training, and IoT firmware are related, but they use
different runtimes and deployment processes. They are therefore separated at
the repository root.

```text
floodguard/
├── frontend/                    # Next.js App Router dashboard
├── backend/                     # FastAPI application
├── ml/                          # Model training and experiments
├── iot/                         # ESP32 firmware and sensor simulator
├── infrastructure/              # Deployment configuration
├── docs/                        # Architecture, datasets, and API notes
├── .env.example
├── docker-compose.yml
└── README.md
```

### Frontend

The frontend follows the standard Next.js App Router organization.

```text
frontend/
├── public/
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── dashboard/
│   │   ├── stations/
│   │   └── alerts/
│   ├── components/
│   ├── hooks/
│   ├── lib/
│   └── types/
├── package.json
└── next.config.ts
```

### Backend

The backend uses a feature-aware layered architecture. API endpoints handle
HTTP concerns, services contain business logic, and repositories own database
queries.

```text
backend/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── api/
│   │   ├── dependencies.py
│   │   └── v1/
│   │       ├── router.py
│   │       └── endpoints/
│   │           ├── health.py
│   │           ├── stations.py
│   │           ├── readings.py
│   │           ├── weather.py
│   │           ├── predictions.py
│   │           └── alerts.py
│   ├── core/
│   │   ├── config.py
│   │   ├── database.py
│   │   ├── logging.py
│   │   └── exceptions.py
│   ├── models/
│   ├── schemas/
│   ├── repositories/
│   ├── services/
│   ├── integrations/
│   │   ├── open_meteo_client.py
│   │   ├── mqtt_client.py
│   │   └── websocket_manager.py
│   ├── ml/
│   │   ├── model_loader.py
│   │   ├── feature_builder.py
│   │   └── inference.py
│   ├── workers/
│   └── utils/
├── alembic/
├── tests/
├── scripts/
├── pyproject.toml
├── alembic.ini
└── Dockerfile
```

Backend request flow:

```text
API endpoint
    → Service
        → Repository → PostgreSQL/PostGIS
        → ML inference
        → External integrations
```

The root `ml/` directory is used to prepare datasets and train models. The
`backend/app/ml/` directory only loads trained model artifacts and performs
inference inside the API.

### Machine Learning

```text
ml/
├── data/
│   ├── raw/
│   ├── processed/
│   └── features/
├── notebooks/
├── src/
│   ├── preprocessing/
│   ├── feature_engineering/
│   ├── training/
│   ├── evaluation/
│   └── inference/
├── artifacts/
└── experiments/
```

### IoT

```text
iot/
├── esp32/
│   └── flood_station.ino
├── simulator/
└── mqtt/
    └── mosquitto.conf
```

The IoT directory stays outside the backend because ESP32 firmware runs on a
device, while the backend runs on a server.

## Prediction Models

### Spatial Flood-Risk Model

Example input features:

- Rainfall totals for the previous 3, 6, 24, and 72 hours
- Forecast rainfall
- Elevation and slope
- Distance to rivers and drainage channels
- Land cover and soil moisture
- Historical flood frequency
- Population or building density

Recommended MVP model: `RandomForestClassifier` or `XGBoost`.

Example output:

```json
{
  "locationId": "GRID-102",
  "floodProbability": 0.78,
  "riskLevel": "HIGH"
}
```

### Water-Level Forecast Model

Example input features:

- Current water level
- Previous 1, 3, 6, and 12-hour water levels
- Rate of water-level change
- Upstream readings
- Recent and forecast rainfall
- Soil moisture and seasonal information

Example output:

```json
{
  "stationId": "YGN-001",
  "currentLevelCm": 185,
  "forecast6hCm": 209,
  "expectedTrend": "RISING",
  "riseProbability": 0.82,
  "riskLevel": "HIGH"
}
```

## Main Database Tables

| Table | Purpose |
|---|---|
| `sensor_stations` | Station identity, location, sensors, and status |
| `sensor_readings` | Water level, rainfall, soil moisture, and battery data |
| `weather_observations` | Current or recent weather data |
| `weather_forecasts` | Hourly forecast data |
| `risk_zones` | PostGIS grid or polygon risk areas |
| `predictions` | Model output and model version |
| `alert_rules` | Thresholds and notification rules |
| `alerts` | Generated warnings and acknowledgement state |
| `model_versions` | Model artifact metadata and evaluation scores |

Spatial locations use PostGIS types such as `POINT` and `POLYGON`.

## Sensor Message Format

Sensor stations publish JSON messages through MQTT.

```json
{
  "stationId": "YGN-001",
  "timestamp": "2026-07-26T06:30:00Z",
  "waterLevelCm": 185.4,
  "rainfallMm": 4.2,
  "soilMoisture": 72,
  "batteryLevel": 88
}
```

The backend validates every message before storing it. Invalid or duplicate
messages should be logged without interrupting the ingestion worker.

## Planned API Endpoints

```text
GET    /api/v1/health

GET    /api/v1/stations
POST   /api/v1/stations
GET    /api/v1/stations/{station_id}

POST   /api/v1/readings
GET    /api/v1/stations/{station_id}/readings

GET    /api/v1/weather/current
GET    /api/v1/weather/forecast

GET    /api/v1/predictions/latest
POST   /api/v1/predictions/run

GET    /api/v1/alerts
PATCH  /api/v1/alerts/{alert_id}/acknowledge

WS     /api/v1/ws/live
```

After the backend starts, interactive API documentation is available at:

```text
http://localhost:8000/docs
```

## Environment Variables

Create environment files from the examples and keep real credentials out of
version control.

```env
# Backend
APP_ENV=development
DATABASE_URL=postgresql+psycopg://geoai_user:your-password@localhost:5432/geoai
MQTT_ENABLED=true
MQTT_BROKER_HOST=127.0.0.1
MQTT_BROKER_PORT=1884
MQTT_TOPIC=floodguard/stations/+/readings
OPEN_METEO_BASE_URL=https://api.open-meteo.com/v1/forecast
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000

# Frontend
NEXT_PUBLIC_API_URL=http://localhost:8000/api/v1
NEXT_PUBLIC_WS_URL=ws://localhost:8000/api/v1/ws/live
```

## Local Development

### Prerequisites

- Node.js 20 or later
- Python 3.11 or later
- PostgreSQL with PostGIS
- Mosquitto MQTT broker
- Docker and Docker Compose, if using containers

### 1. Clone the project

```bash
git clone <repository-url>
cd floodguard
```

### 2. Start the local MQTT broker

Install Mosquitto on Windows, set the MQTT credential fields in
`backend/.env`, then run:

```powershell
cd backend
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\setup_local_mosquitto.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\start_local_mosquitto.ps1
```

### 3. Start the backend

```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
alembic upgrade head
uvicorn app.main:app --reload
```

### 4. Start the frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:3000`.

### 5. Run the sensor simulator

Preview mode does not publish or change the database:

```powershell
python .\iot\simulator\simulate_sensor.py --station-id MAUBIN-01 --count 3
```

See `iot/simulator/README.md` for the explicit `--publish` workflow.

## Testing

Backend:

```bash
cd backend
pytest
```

Frontend:

```bash
cd frontend
npm run lint
npm run test
```

## Hackathon MVP Scope

- [ ] One ESP32 water-level monitoring station
- [x] MQTT sensor ingestion bridge
- [x] Sensor-data simulator (preview-safe, explicitly labelled)
- [x] Open-Meteo integration
- [x] ERA5 historical rainfall dashboard with rolling accumulation features
- [x] Maubin GFD historical flood-frequency labels (2000–2018), PostGIS/API/import pipeline, and 2D/3D/Cesium rendering
- [x] Versioned 5,549-cell historical ML dataset and spatially validated logistic susceptibility baseline
- [x] PostgreSQL/PostGIS storage
- [x] Explainable sensor-independent terrain susceptibility screening
- [x] ESA WorldCover 2021 land-cover enrichment for every terrain cell
- [x] Data provenance, licence, and quality-status catalog
- [ ] Water-level and flood-risk prediction
- [x] Next.js interactive map dashboard
- [x] Leaflet/OpenStreetMap basemap with terrain, susceptibility, land-cover,
  and waterway overlays
- [x] Switchable MapLibre 3D terrain view with pitch, rotation, and adjustable
  visual exaggeration
- [x] Optional CesiumJS globe view with streamed elevation terrain and the same
  GeoAI overlays
- [x] Live water-level chart
- [x] Four-level risk classification
- [x] Demonstration threshold warning

The MVP intentionally excludes Kubernetes, Kafka, deep-learning models, a
separate mobile app, and nationwide sensor coverage.

## Data Limitations

- NASA IMERG Early Run is delayed and must not be treated as an instant warning
  source.
- Satellite rainfall represents an area and may differ from rainfall measured
  at a specific station.
- Weather forecasts contain uncertainty and can change between updates.
- Terrain susceptibility is a relative prioritization index, not flood
  probability, depth, or arrival time; the current score does not yet weight
  the available 2021 land-cover composition and still omits levees, drainage
  capacity, tides, soil, and historical flood calibration.
- Sensor readings may be affected by placement, connectivity, calibration, or
  power issues.
- Model predictions support decisions; they do not guarantee that flooding will
  or will not occur.

For urgent alerts, the system should prioritize current local sensor readings,
combine them with forecasts, and clearly display the data timestamp and source.

## Future Improvements

- Add LoRa or 4G support for remote stations
- Add upstream/downstream river-station relationships
- Add SMS, mobile push, and community alert channels
- Add rainfall radar and additional satellite products
- Add model monitoring and scheduled retraining
- Add offline-first support for low-connectivity areas
- Expand from pilot locations to regional coverage

## Contributing

1. Create a feature branch.
2. Keep changes focused on one feature or fix.
3. Add or update tests where practical.
4. Run linting and tests before opening a pull request.
5. Describe any API, database, model, or environment-variable changes.

## License

The project license has not yet been selected.
