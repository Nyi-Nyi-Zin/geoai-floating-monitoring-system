import numpy as np
from datetime import date

import pytest

from app.services.flood_ml import calculate_event_readiness
from scripts.build_flood_event_dataset import _append_engineered_features, temporal_split_map
from scripts.train_flood_event_model import (
    calibration_report,
    ranking_diagnostics,
    select_decision_threshold,
    select_precision_threshold,
    select_screening_threshold,
)

from scripts.train_flood_susceptibility import (
    average_precision,
    evaluate,
    fit_logistic,
    risk_band,
    roc_auc,
    spatial_split,
)


def test_spatial_split_is_deterministic() -> None:
    assert spatial_split(95.65, 16.73) == spatial_split(95.65, 16.73)
    assert spatial_split(95.65, 16.73) in {"train", "validation", "test"}


def test_numpy_logistic_learns_separable_signal() -> None:
    x = np.array([[-2.0], [-1.0], [1.0], [2.0]])
    y = np.array([0.0, 0.0, 1.0, 1.0])
    weights, intercept = fit_logistic(
        x, y, iterations=1500, learning_rate=0.05, l2=0.01
    )

    assert weights[0] > 0
    assert intercept == intercept


def test_metrics_and_risk_bands() -> None:
    truth = np.array([0.0, 0.0, 1.0, 1.0])
    probability = np.array([0.1, 0.2, 0.8, 0.9])

    assert roc_auc(truth, probability) == 1.0
    assert average_precision(truth, probability) == 1.0
    assert evaluate(truth, probability)["f1"] == 1.0
    assert [risk_band(value) for value in (0.1, 0.3, 0.6, 0.9)] == [
        "LOW",
        "MODERATE",
        "HIGH",
        "VERY_HIGH",
    ]


def test_openapi_lists_flood_ml_endpoints(client) -> None:
    paths = client.get("/openapi.json").json()["paths"]

    assert "/api/v1/flood-ml/models/latest" in paths
    assert "/api/v1/flood-ml/predictions/index" in paths
    assert "/api/v1/flood-ml/event-readiness" in paths
    assert "/api/v1/flood-ml/event-models/latest" in paths
    assert "/api/v1/flood-ml/event-predictions/index" in paths


def test_temporal_split_holds_out_latest_events() -> None:
    splits = temporal_split_map(
        [
            ("1", date(2010, 1, 1)),
            ("2", date(2011, 1, 1)),
            ("3", date(2012, 1, 1)),
            ("4", date(2013, 1, 1)),
        ]
    )

    assert splits == {"1": "train", "2": "train", "3": "validation", "4": "test"}


def test_temporal_split_uses_multiple_holdout_events_when_available() -> None:
    events = [
        (str(index), date(2000 + index, 1, 1)) for index in range(1, 18)
    ]

    splits = temporal_split_map(events)

    assert list(splits.values()).count("train") == 11
    assert list(splits.values()).count("validation") == 3
    assert list(splits.values()).count("test") == 3
    assert splits["17"] == "test"


def test_temporal_split_requires_four_events() -> None:
    with pytest.raises(ValueError, match="At least 4"):
        temporal_split_map([("1", date(2010, 1, 1))])


def test_engineered_event_features_capture_hydrology_context() -> None:
    row = {
        "distance_to_waterway_m": 125.0,
        "elevation_percentile": 0.2,
        "local_relief_m": 1.0,
        "rainfall_accumulation_3d_mm": 60.0,
        "rainfall_accumulation_7d_mm": 120.0,
        "rainfall_accumulation_30d_mm": 300.0,
        "rainfall_max_1d_mm": 40.0,
        "landcover_water_pct": 0.10,
        "landcover_wetland_pct": 0.20,
        "landcover_mangrove_pct": 0.05,
    }

    _append_engineered_features(row)

    assert row["waterway_proximity_index"] == pytest.approx(2 / 3, rel=1e-6)
    assert row["surface_water_influence_pct"] == pytest.approx(0.35)
    assert row["flatness_index"] == pytest.approx(0.5)
    assert row["rainfall_7d_x_waterway_proximity"] == pytest.approx(80.0)
    assert row["rainfall_30d_x_low_elevation"] == pytest.approx(240.0)
    assert row["rainfall_3d_x_surface_water"] == pytest.approx(21.0)
    assert row["rainfall_7d_x_flatness"] == pytest.approx(60.0)


def test_event_readiness_requires_event_date_rainfall_alignment() -> None:
    event_dates = [date(2010 + index, 1, 1) for index in range(4)]

    ready, blockers = calculate_event_readiness(event_dates, set(event_dates))
    missing_ready, missing_blockers = calculate_event_readiness(
        event_dates, set(event_dates[:3])
    )

    assert ready is True
    assert blockers == []
    assert missing_ready is False
    assert "currently 3" in missing_blockers[0]


def test_event_threshold_is_selected_from_validation_f1() -> None:
    truth = np.array([0.0, 0.0, 1.0, 1.0])
    probability = np.array([0.1, 0.4, 0.45, 0.9])

    threshold, metrics = select_decision_threshold(truth, probability)

    assert 0.4 < threshold <= 0.45
    assert metrics["f1"] == 1.0


def test_precision_threshold_respects_recall_floor() -> None:
    truth = np.array([0.0, 0.0, 0.0, 1.0, 1.0, 1.0])
    probability = np.array([0.05, 0.55, 0.60, 0.58, 0.70, 0.95])

    balanced_threshold, balanced = select_decision_threshold(truth, probability)
    conservative_threshold, conservative = select_precision_threshold(
        truth, probability, minimum_recall=0.60
    )

    assert conservative_threshold >= balanced_threshold
    assert conservative["precision"] >= balanced["precision"]
    assert conservative["recall"] >= 0.60


def test_screening_threshold_prefers_recall_with_precision_floor() -> None:
    truth = np.array([0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0])
    probability = np.array([0.12, 0.18, 0.24, 0.30, 0.22, 0.40, 0.75, 0.95])

    balanced_threshold, balanced = select_decision_threshold(truth, probability)
    screening_threshold, screening = select_screening_threshold(
        truth, probability, minimum_precision=0.50
    )

    assert screening_threshold <= balanced_threshold
    assert screening["recall"] >= balanced["recall"]
    assert screening["precision"] >= 0.50


def test_precision_threshold_falls_back_when_recall_floor_is_impossible() -> None:
    truth = np.array([0.0, 0.0, 1.0, 1.0])
    probability = np.array([0.1, 0.2, 0.8, 0.9])

    threshold, metrics = select_precision_threshold(
        truth, probability, minimum_recall=1.0
    )

    assert threshold <= 0.8
    assert metrics["recall"] == 1.0


def test_calibration_report_is_zero_for_perfect_probabilities() -> None:
    truth = np.array([0.0, 0.0, 1.0, 1.0])
    probability = np.array([0.0, 0.0, 1.0, 1.0])

    report = calibration_report(truth, probability, bins=4)

    assert report["expected_calibration_error"] == 0.0
    assert report["maximum_calibration_error"] == 0.0


def test_ranking_diagnostics_reports_top_slice_precision() -> None:
    truth = np.array([1.0, 0.0, 1.0, 0.0, 0.0])
    probability = np.array([0.95, 0.80, 0.60, 0.30, 0.10])

    report = ranking_diagnostics(truth, probability, fractions=(0.4,))

    assert report["top_40pct"]["cells"] == 2
    assert report["top_40pct"]["true_positive_cells"] == 1
    assert report["top_40pct"]["precision"] == 0.5
