"""Build event-cell labels aligned with rainfall on each flood event date."""

from __future__ import annotations

import argparse
import csv
import math
from datetime import date
from pathlib import Path
from typing import Any

from sqlalchemy import text

from app.db.session import engine
from scripts.train_flood_susceptibility import FEATURE_NAMES as STATIC_FEATURE_NAMES

RAINFALL_FEATURE_NAMES = [
    "rainfall_mean_1d_mm",
    "rainfall_max_1d_mm",
    "rainfall_p90_1d_mm",
    "rainfall_accumulation_3d_mm",
    "rainfall_accumulation_7d_mm",
    "rainfall_accumulation_30d_mm",
]
ENGINEERED_FEATURE_NAMES = [
    "waterway_proximity_index",
    "surface_water_influence_pct",
    "flatness_index",
    "rainfall_7d_x_waterway_proximity",
    "rainfall_30d_x_low_elevation",
    "rainfall_3d_x_surface_water",
    "rainfall_7d_x_flatness",
    "rainfall_intensity_ratio",
]
FEATURE_NAMES = [
    *STATIC_FEATURE_NAMES,
    *RAINFALL_FEATURE_NAMES,
    *ENGINEERED_FEATURE_NAMES,
]

EVENT_DATASET_SQL = text(
    """
    WITH events AS (
      SELECT
        event_id,
        MIN(observed_start_date) AS event_start_date,
        MAX(observed_end_date) AS event_end_date,
        ST_UnaryUnion(ST_Collect(geometry)) AS geometry
      FROM flood_extents
      WHERE event_id IS NOT NULL AND observed_start_date IS NOT NULL
      GROUP BY event_id
    ),
    cells AS (
      SELECT
        id,
        name,
        geometry,
        properties,
        ST_Area(geometry::geography) AS cell_area_m2,
        ST_X(ST_Centroid(geometry)) AS centroid_lon,
        ST_Y(ST_Centroid(geometry)) AS centroid_lat
      FROM geo_assets
      WHERE asset_type = 'terrain_cell'
    )
    SELECT
      e.event_id,
      e.event_start_date,
      e.event_end_date,
      c.id AS geo_asset_id,
      c.name,
      c.centroid_lon,
      c.centroid_lat,
      LEAST(1.0, GREATEST(0.0,
        CASE WHEN ST_Intersects(c.geometry, e.geometry)
          THEN ST_Area(ST_Intersection(c.geometry, e.geometry)::geography)
               / NULLIF(c.cell_area_m2, 0)
          ELSE 0 END
      )) AS flooded_fraction,
      (c.properties->>'elevation_mean_m')::double precision AS elevation_mean_m,
      (c.properties->>'elevation_min_m')::double precision AS elevation_min_m,
      (c.properties->>'elevation_max_m')::double precision AS elevation_max_m,
      COALESCE((c.properties->>'elevation_stddev_m')::double precision, 0) AS elevation_stddev_m,
      (c.properties->>'elevation_percentile')::double precision AS elevation_percentile,
      (c.properties->>'distance_to_waterway_m')::double precision AS distance_to_waterway_m,
      (c.properties->>'local_relief_m')::double precision AS local_relief_m,
      COALESCE((c.properties->'land_cover_percentages'->>'10')::double precision, 0) AS landcover_tree_pct,
      COALESCE((c.properties->'land_cover_percentages'->>'20')::double precision, 0) AS landcover_shrub_pct,
      COALESCE((c.properties->'land_cover_percentages'->>'30')::double precision, 0) AS landcover_grass_pct,
      COALESCE((c.properties->'land_cover_percentages'->>'40')::double precision, 0) AS landcover_cropland_pct,
      COALESCE((c.properties->'land_cover_percentages'->>'50')::double precision, 0) AS landcover_built_pct,
      COALESCE((c.properties->'land_cover_percentages'->>'60')::double precision, 0) AS landcover_bare_pct,
      COALESCE((c.properties->'land_cover_percentages'->>'80')::double precision, 0) AS landcover_water_pct,
      COALESCE((c.properties->'land_cover_percentages'->>'90')::double precision, 0) AS landcover_wetland_pct,
      COALESCE((c.properties->'land_cover_percentages'->>'95')::double precision, 0) AS landcover_mangrove_pct,
      r.mean_precipitation_mm AS rainfall_mean_1d_mm,
      r.max_precipitation_mm AS rainfall_max_1d_mm,
      r.p90_precipitation_mm AS rainfall_p90_1d_mm,
      r.accumulation_3d_mm AS rainfall_accumulation_3d_mm,
      r.accumulation_7d_mm AS rainfall_accumulation_7d_mm,
      r.accumulation_30d_mm AS rainfall_accumulation_30d_mm
    FROM events AS e
    JOIN rainfall_history AS r ON r.observed_date = e.event_start_date
    CROSS JOIN cells AS c
    ORDER BY e.event_start_date, e.event_id, c.id
    """
)


def temporal_split_map(events: list[tuple[str, date]]) -> dict[str, str]:
    ordered = sorted(set(events), key=lambda item: (item[1], item[0]))
    if len(ordered) < 4:
        raise ValueError(
            "At least 4 rainfall-aligned events are required for temporal splits"
        )
    holdout_count = max(1, len(ordered) // 5)
    if len(ordered) - (2 * holdout_count) < 2:
        holdout_count = 1
    result = {event_id: "train" for event_id, _ in ordered}
    for event_id, _ in ordered[-2 * holdout_count : -holdout_count]:
        result[event_id] = "validation"
    for event_id, _ in ordered[-holdout_count:]:
        result[event_id] = "test"
    return result


def load_event_dataset() -> list[dict[str, Any]]:
    if engine is None:
        raise RuntimeError("DATABASE_URL is required")
    with engine.connect() as connection:
        rows = [dict(row) for row in connection.execute(EVENT_DATASET_SQL).mappings()]
    if not rows:
        raise RuntimeError(
            "No event/rainfall-aligned rows are available. Check /flood-ml/event-readiness."
        )
    for row in rows:
        row["event_id"] = str(row["event_id"])
        row["flooded_fraction"] = float(row["flooded_fraction"])
        for feature in [*STATIC_FEATURE_NAMES, *RAINFALL_FEATURE_NAMES]:
            if row[feature] is None:
                raise ValueError(f"Missing {feature} for event {row['event_id']}")
            row[feature] = float(row[feature])
        _append_engineered_features(row)
    return rows


def _append_engineered_features(row: dict[str, Any]) -> None:
    distance_to_waterway = max(float(row["distance_to_waterway_m"]), 0.0)
    elevation_percentile = min(max(float(row["elevation_percentile"]), 0.0), 1.0)
    local_relief = max(float(row["local_relief_m"]), 0.0)
    rainfall_3d = max(float(row["rainfall_accumulation_3d_mm"]), 0.0)
    rainfall_7d = max(float(row["rainfall_accumulation_7d_mm"]), 0.0)
    rainfall_30d = max(float(row["rainfall_accumulation_30d_mm"]), 0.0)
    rainfall_max_1d = max(float(row["rainfall_max_1d_mm"]), 0.0)
    surface_water_influence = min(
        1.0,
        max(
            0.0,
            float(row["landcover_water_pct"])
            + float(row["landcover_wetland_pct"])
            + float(row["landcover_mangrove_pct"]),
        ),
    )
    low_elevation_index = 1.0 - elevation_percentile
    waterway_proximity_index = 1.0 / (1.0 + distance_to_waterway / 250.0)
    flatness_index = 1.0 / (1.0 + local_relief)

    row["waterway_proximity_index"] = waterway_proximity_index
    row["surface_water_influence_pct"] = surface_water_influence
    row["flatness_index"] = flatness_index
    row["rainfall_7d_x_waterway_proximity"] = rainfall_7d * waterway_proximity_index
    row["rainfall_30d_x_low_elevation"] = rainfall_30d * low_elevation_index
    row["rainfall_3d_x_surface_water"] = rainfall_3d * surface_water_influence
    row["rainfall_7d_x_flatness"] = rainfall_7d * flatness_index
    row["rainfall_intensity_ratio"] = rainfall_max_1d / max(
        1.0, math.sqrt(rainfall_7d * max(rainfall_30d, 1.0))
    )


def export_event_dataset(
    rows: list[dict[str, Any]], output: Path, target_threshold: float
) -> dict[str, int]:
    splits = temporal_split_map(
        [(row["event_id"], row["event_start_date"]) for row in rows]
    )
    fields = [
        "event_id",
        "event_start_date",
        "event_end_date",
        "geo_asset_id",
        "name",
        "centroid_lon",
        "centroid_lat",
        *FEATURE_NAMES,
        "flooded_fraction",
        "target_label",
        "temporal_split",
    ]
    output.parent.mkdir(parents=True, exist_ok=True)
    counts = {"train": 0, "validation": 0, "test": 0}
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            split = splits[row["event_id"]]
            counts[split] += 1
            writer.writerow(
                {
                    **{name: row[name] for name in fields if name in row},
                    "target_label": int(row["flooded_fraction"] >= target_threshold),
                    "temporal_split": split,
                }
            )
    return counts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data/derived/maubin_flood_event_dataset_v1.csv"),
    )
    parser.add_argument("--target-threshold", type=float, default=0.10)
    args = parser.parse_args()
    rows = load_event_dataset()
    counts = export_event_dataset(rows, args.output, args.target_threshold)
    print(
        {
            "events": len({row["event_id"] for row in rows}),
            "rows": len(rows),
            "split_rows": counts,
            "output": str(args.output),
        }
    )


if __name__ == "__main__":
    main()
