# DeltaWatch frontend

Next.js 16 dashboard for the Maubin Township flood GeoAI project. It fetches
health, waterways, the township boundary, and paginated 500 m terrain cells
from FastAPI on the server. The client offers a 2D Leaflet view, a regional 3D
MapLibre terrain view, and an optional CesiumJS globe view with switchable Esri
World Imagery satellite and OpenStreetMap street basemaps. Context remains visible beneath
the elevation, relative susceptibility, ESA WorldCover land-cover,
township-boundary, and waterway overlays. All views support terrain-cell
inspection and layer switching. Both 3D engines support pitch, rotation and
adjustable vertical exaggeration; Cesium additionally provides a true WGS84
globe camera and streamed elevation terrain.
The Historical flood layer renders stored satellite-observed polygons in 2D,
MapLibre 3D, and Cesium. The current Maubin GFD 2000–2018 composite preserves
1–8 observed-event frequency classes with a cyan-to-magenta palette. The
control remains disabled whenever the API returns no labels, preventing
placeholder geometry from being mistaken for observed inundation.
The ML probability layer joins the latest versioned prediction index to the
same 5,549 terrain cells. It uses four probability bands, shows the selected
cell's historical label and model version, and displays spatial-test metrics.
Every label describes this as historical susceptibility rather than a live
flood forecast.
The `Event hindcast` layer uses the rainfall-aligned experimental model for
held-out historical GFD events. The event selector switches among validation
and test dates, while the inspector shows probability, observed flooded share,
the validation-calibrated threshold, and test metrics. This layer is not a
future forecast or operational warning.
It also loads rainfall forecasts, registered stations, recent observations,
threshold alerts, and a real-data-only water-level chart. New HTTP/ESP32
readings are pushed to the chart through the backend WebSocket channel.
The historical-input panel visualizes the latest year of area-weighted Maubin
ERA5 reanalysis with 30-day, 90-day, and one-year windows, daily rainfall bars,
and a rolling seven-day accumulation line.

The susceptibility layer combines relative elevation (55%), mapped-waterway
proximity (30%), and local flatness (15%). Selecting a cell shows the score and
each weighted contribution. This is transparent terrain screening derived from
Copernicus DEM GLO-30 and OpenStreetMap—not flood depth, probability, or
arrival-time prediction.

The land-cover layer colors each 500 m cell by its dominant ESA WorldCover 2021
class. Selecting a cell shows the class composition derived from the original
10 m pixels. This is a descriptive historical evidence layer and is not
weighted in the current susceptibility score.

The data-provenance section lists every active source with provider, format,
resolution, quality status, licence/source links, known limitations, and usage
constraints. In particular, it surfaces the MIMU restriction that online use
requires prior written agreement instead of hiding it in backend metadata.

## Configure

Copy the environment example:

```powershell
Copy-Item .env.example .env.local
```

Default:

```dotenv
API_BASE_URL=http://127.0.0.1:8000/api/v1
NEXT_PUBLIC_API_URL=http://127.0.0.1:8000/api/v1
NEXT_PUBLIC_WS_URL=ws://127.0.0.1:8000/api/v1/ws/live
NEXT_PUBLIC_MAP_TILE_URL=https://tile.openstreetmap.org/{z}/{x}/{y}.png
NEXT_PUBLIC_TERRAIN_TILEJSON_URL=https://tiles.mapterhorn.com/tilejson.json
NEXT_PUBLIC_CESIUM_TERRAIN_URL=https://elevation3d.arcgis.com/arcgis/rest/services/WorldElevation3D/Terrain3D/ImageServer
NEXT_PUBLIC_CESIUM_ION_TOKEN=
```

`API_BASE_URL` is server-only and is not bundled into browser JavaScript.
`NEXT_PUBLIC_API_URL` lets the browser load the large terrain and compact
screening datasets after the initial page renders, avoiding a multi-megabyte
server-rendered HTML response. Its origin must be allowed by backend CORS.
`NEXT_PUBLIC_WS_URL` is intentionally public because the browser connects to
that endpoint directly. Use `wss://` when the dashboard is served over HTTPS.
`NEXT_PUBLIC_MAP_TILE_URL` is configurable so a production deployment can move
to a contracted or self-hosted tile service without changing application code.
The default OpenStreetMap standard tile endpoint is for normal interactive
viewing only: keep attribution visible, do not bulk-download or prefetch tiles,
and use a suitable provider for production traffic.
`NEXT_PUBLIC_TERRAIN_TILEJSON_URL` supplies the raster elevation tiles used by
MapLibre's 3D terrain renderer. The default Mapterhorn source uses Terrarium
encoding and keeps its required attribution visible.
`NEXT_PUBLIC_CESIUM_TERRAIN_URL` is the token-free default terrain service for
the Cesium view. Set `NEXT_PUBLIC_CESIUM_ION_TOKEN` to use Cesium World Terrain
instead. This is a public browser variable: use a scoped ion token with only the
assets and origins the deployment requires.
`NEXT_PUBLIC_CESIUM_SATELLITE_URL` configures the Cesium satellite basemap. The
dashboard starts in Satellite mode and provides a Satellite / Streets switch.

## Read the map

Select `Susceptibility` and click a coloured 500 m cell. The inspector shows its
relative 0–100 ranking and the elevation, waterway-proximity, and flatness
contributions. Red `VERY HIGH` cells are higher screening priorities, not a
guaranteed flood-arrival sequence or a flood probability. Select `Waterways` to
hide the grid and inspect the mapped river/canal network over the basemap.
Select `Land cover` to compare cropland, permanent water, tree cover, wetland,
built-up, and other classes; click a cell to see its percentage composition.
Use the `2D` / `3D` / `Cesium` switch above the map to change views. In 3D,
drag to pan or orbit, rotate and tilt, and adjust the vertical exaggeration
slider to make Maubin's very subtle relief visible. The MapLibre view is the
lighter regional renderer; Cesium is the globe/digital-twin path.
Exaggeration changes presentation only: it is not flood depth, probability, or
a model prediction.

The ERA5 history chart is a coarse reanalysis baseline for feature engineering
and calibration. It is not a local gauge record, live inundation observation,
or flood warning.

Cesium requires static runtime assets. `predev` and `prebuild` run
`scripts/copy-cesium-assets.mjs` automatically and copy the installed version's
Workers, ThirdParty, Assets, and Widgets directories to the ignored
`public/cesium` runtime folder.

## Run

Start the backend first:

```powershell
cd D:\geo-ai-floating-predection\backend
.\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --port 8000
```

Then start the frontend:

```powershell
cd D:\geo-ai-floating-predection\frontend
pnpm dev
```

Open <http://127.0.0.1:3000>.

## Verify

```powershell
pnpm lint
pnpm build
```
